public enum Tipo {
    BARCO("BARCO"),
    CAMINHÃOTANQUE("CAMINHÃOTANQUE"),

    ESCAVADEIRA("ESCAVADEIRA");

    private String equipa;

    Tipo(String equipa) {
        this.equipa=equipa;
    }










}
